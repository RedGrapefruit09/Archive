# Security Policy

This is a Minecraft mod and not much attention is needed to security.  
I promise that my mods aren't malware and won't damage your system in any way.

## Supported Versions

Security updates hardly ever happen, but I keep a list of support versions just in case.

| Version | Supported          |
| ------- | ------------------ |
| 0.1     | :white_check_mark: |

## Reporting a Vulnerability

If you somehow found a vulnerability, ~contact your therapist~, I mean, email me at karpovanton729@gmail.com and I'll
try my best at resolving the issue.  
Do keep in mind that I'm **not** a security expert and there's not much I can do.

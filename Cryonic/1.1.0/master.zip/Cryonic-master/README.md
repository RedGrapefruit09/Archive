# About

Cryonic is a 1.17 Fabric mod that makes food and drinks more realistic.

Build: `gradlew build`\
Artifact will be at `build/libs/cryonic-X.jar`


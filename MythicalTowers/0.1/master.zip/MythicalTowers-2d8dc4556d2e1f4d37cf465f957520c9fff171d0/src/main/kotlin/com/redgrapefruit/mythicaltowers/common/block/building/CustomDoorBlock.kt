package com.redgrapefruit.mythicaltowers.common.block.building

import net.minecraft.block.DoorBlock

/**
 * Custom door
 */
class CustomDoorBlock(settings: Settings) : DoorBlock(settings)
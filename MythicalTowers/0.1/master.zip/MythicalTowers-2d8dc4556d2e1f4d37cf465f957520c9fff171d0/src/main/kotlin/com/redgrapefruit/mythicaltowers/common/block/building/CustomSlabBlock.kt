package com.redgrapefruit.mythicaltowers.common.block.building

import net.minecraft.block.SlabBlock

class CustomSlabBlock(settings: Settings) : SlabBlock(settings)
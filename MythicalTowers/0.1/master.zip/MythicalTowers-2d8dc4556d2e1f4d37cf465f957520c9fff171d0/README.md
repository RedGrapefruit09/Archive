[![build](https://github.com/RedGrapefruit09/MythicalTowers/actions/workflows/build.yml/badge.svg)](https://github.com/RedGrapefruit09/MythicalTowers/actions/workflows/build.yml)

The mod is currently early work-in-progress.  
Feel free to browse the code and contribute.  
Expected release date: around 15th July

YouTrack link: [here](https://redgrapefruit.myjetbrains.com/youtrack/issues).  
Check out the Issues with `MT` prefix
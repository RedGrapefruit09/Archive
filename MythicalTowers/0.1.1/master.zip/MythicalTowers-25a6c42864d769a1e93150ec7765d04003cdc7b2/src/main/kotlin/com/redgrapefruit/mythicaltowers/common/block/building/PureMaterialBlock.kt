package com.redgrapefruit.mythicaltowers.common.block.building

import net.minecraft.block.Block

/**
 * A block from pure material. (Example: Green Block)
 */
class PureMaterialBlock(settings: Settings) : Block(settings)
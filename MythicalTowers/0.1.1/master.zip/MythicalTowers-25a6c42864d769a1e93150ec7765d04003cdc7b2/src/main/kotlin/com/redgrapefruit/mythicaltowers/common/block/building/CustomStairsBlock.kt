package com.redgrapefruit.mythicaltowers.common.block.building

import net.minecraft.block.BlockState
import net.minecraft.block.StairsBlock

/**
 * Custom stairs
 */
class CustomStairsBlock(base: BlockState, settings: Settings) : StairsBlock(base, settings)
package com.redgrapefruit.mythicaltowers.common.block.building

import net.minecraft.block.Block

/**
 * Custom-colored bricks
 */
class CustomBricksBlock(settings: Settings) : Block(settings)
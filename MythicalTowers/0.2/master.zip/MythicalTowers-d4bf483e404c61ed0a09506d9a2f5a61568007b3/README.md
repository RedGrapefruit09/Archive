[![build](https://github.com/RedGrapefruit09/MythicalTowers/actions/workflows/build.yml/badge.svg)](https://github.com/RedGrapefruit09/MythicalTowers/actions/workflows/build.yml)

# State

This mod is currently work-in-progress.  
It's expected to release in the end of July or start of August, 2021.

# Install

The mod can be installed via the [Grape Installer](https://github.com/RedGrapefruit09/GrapeInstaller/releases).  
Click on the latest release and download the JAR file or the OS binary file.  
Open the JAR / extract and open the binary.  
Enter your `mods` folder into the top field.  
Click on `Install` in the `MythicalTowers` section.  
After some time, the mod should have downloaded and you can launch the game!

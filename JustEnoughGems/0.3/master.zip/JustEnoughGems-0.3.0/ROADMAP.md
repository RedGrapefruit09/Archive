
## Roadmap

The official roadmap for this mod's development.\
The release date is, as of now, **Q1-2022**.

Here's the full status on releases:

| Index | Summary | Availability |
|-|-|-|
| v0.1 | Gems | :white_check_mark: |
| v0.2 | Amulets | :white_check_mark: |
| v0.3 | Weapons | 🚧 |
| v0.4 | Shields | :x: |
| v0.5 | Ores, Mining system | :x: |
| v0.6 | Tools | :x: |
| v0.7 | Armor | :x: |
| v0.8 | Food | :x: |
| v1.0 | **Stable release** | :x: |

package com.redgrapefruit.justenoughgems.client

import net.fabricmc.api.ClientModInitializer

object JEGClient : ClientModInitializer {
    override fun onInitializeClient() {

    }
}

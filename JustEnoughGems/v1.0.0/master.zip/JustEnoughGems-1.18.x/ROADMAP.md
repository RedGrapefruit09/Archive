
## Roadmap

The official roadmap for this mod's development.\
The release date is, as of now, **Q1-2022**.

Here's the full status on releases:

| Index | Summary | Availability |
|-|-|-|
| v0.1 | Gems | :white_check_mark: |
| v0.2 | Amulets | :white_check_mark: |
| v0.3 | Weapons | :white_check_mark: |
| v0.4 | Shields | :white_check_mark: |
| v0.5 | Ores, Mining system | :white_check_mark: |
| v0.6 | Tools | :white_check_mark: |
| v0.7 | Armor | :white_check_mark: |
| v0.8 | Food | 🚧 |
| v1.0 | **Stable release** | :x: |


# MiniManager

MiniManager is a stripped-down temporary solution for distributing my mods while [Gestor](https://github.com/GestorMC/Gestor) is still in-dev.\
It has some limitations, but it'll do for the time being.

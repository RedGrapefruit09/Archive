import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.window.Tray
import androidx.compose.ui.window.Window
import androidx.compose.ui.window.application

private const val UTOPIA_MAIN = "https://github.com/RedGrapefruit09/MiniManager/blob/master/dists/utopia_main.jar?raw=true"
private const val UTOPIA_CROPTOPIA = "https://github.com/RedGrapefruit09/MiniManager/blob/master/dists/utopia_croptopia.jar?raw=true"
private const val UTOPIA_PATCHOULI = "https://github.com/RedGrapefruit09/MiniManager/blob/master/dists/utopia_patchouli.jar?raw=true"
private const val UTOPIA_DEHYDRATION = "https://github.com/RedGrapefruit09/MiniManager/blob/master/dists/utopia_dehydration.jar?raw=true"
private const val MYTHICALTOWERS_MAIN = "https://github.com/RedGrapefruit09/MiniManager/blob/master/dists/mythicaltowers_main.jar?raw=true"

/**
 * A util for using the right filesystem separator
 */
fun String.separate(): String {
    val sep = System.getProperty("file.separator")
    return replace("%", sep)
}

fun main() = application {
    var isVisible by remember { mutableStateOf(true) }

    Window(onCloseRequest = { isVisible = false }, visible = isVisible, title = "MiniManager", resizable = false, icon = painterResource("logo.png")) {
        val home = System.getProperty("user.home")
        var modsFolderText by remember { mutableStateOf(TextFieldValue("$home%MiniManager%mods".separate())) }
        var cacheFolderText by remember { mutableStateOf(TextFieldValue("$home%MiniManager%cache".separate())) }

        initCache(cacheFolderText.text)

        MaterialTheme {
            Column {
                Row(modifier = Modifier.padding(200.dp, 0.dp)) {
                    Text(
                        text = "Settings",
                        fontWeight = FontWeight.Bold,
                        fontSize = 1.8.em
                    )
                }

                // region Settings

                Row(modifier = Modifier.padding(7.dp, 25.dp)) {
                    Text(
                        text = "Mods folder: ",
                        fontSize = 1.4.em,
                        modifier = Modifier.padding(2.dp, 8.dp)
                    )

                    TextField(
                        value = modsFolderText,
                        onValueChange = { new -> modsFolderText = new },
                        textStyle = TextStyle(fontSize = 1.3.em)
                    )
                }

                Row(modifier = Modifier.padding(7.dp, 5.dp)) {
                    Text(
                        text = "Cache folder: ",
                        fontSize = 1.4.em,
                        modifier = Modifier.padding(2.dp, 8.dp)
                    )

                    TextField(
                        value = cacheFolderText,
                        onValueChange = { new -> cacheFolderText = new },
                        textStyle = TextStyle(fontSize = 1.3.em)
                    )
                }

                // endregion

                Row(modifier = Modifier.padding(200.dp, 20.dp)) {
                    Text(
                        text = "Mods",
                        fontWeight = FontWeight.Bold,
                        fontSize = 1.8.em
                    )
                }

                // region Utopia

                Row(modifier = Modifier.padding(7.dp, 5.dp)) {
                    Text(
                        text = "Utopia",
                        fontSize = 1.5.em,
                        modifier = Modifier.padding(2.dp, 10.dp)
                    )

                    Spacer(Modifier.width(75.0.dp).height(0.0.dp))

                    Button(
                        onClick = {
                            installMod("utopia", UTOPIA_MAIN, modsFolderText.text)
                            installMod("utopia_croptopia", UTOPIA_CROPTOPIA, modsFolderText.text)
                            installMod("utopia_patchouli", UTOPIA_PATCHOULI, modsFolderText.text)
                            installMod("utopia_dehydration", UTOPIA_DEHYDRATION, modsFolderText.text)
                        },
                        colors = ButtonDefaults.buttonColors(backgroundColor = Color.Green, contentColor = Color.White),
                        content = {
                            Text(
                                text = "Download",
                                fontSize = 1.3.em,
                                modifier = Modifier.padding(7.dp, 0.dp)
                            )
                        },
                        modifier = Modifier.padding(7.dp, 0.dp)
                    )

                    Button(
                        onClick = {
                            updateMod("utopia", UTOPIA_MAIN, modsFolderText.text, cacheFolderText.text)
                            updateMod("utopia_croptopia", UTOPIA_CROPTOPIA, modsFolderText.text, cacheFolderText.text)
                            updateMod("utopia_patchouli", UTOPIA_PATCHOULI, modsFolderText.text, cacheFolderText.text)
                            updateMod("utopia_dehydration", UTOPIA_DEHYDRATION, modsFolderText.text, cacheFolderText.text)
                        },
                        colors = ButtonDefaults.buttonColors(backgroundColor = Color.Blue, contentColor = Color.White),
                        content = {
                            Text(
                                text = "Update",
                                fontSize = 1.3.em,
                                modifier = Modifier.padding(7.dp, 0.dp)
                            )
                        },
                        modifier = Modifier.padding(10.dp, 0.dp)
                    )

                    Button(
                        onClick = {
                            removeMod("utopia", modsFolderText.text)
                            removeMod("utopia_croptopia", modsFolderText.text)
                            removeMod("utopia_patchouli", modsFolderText.text)
                            removeMod("utopia_dehydration", modsFolderText.text)
                        },
                        colors = ButtonDefaults.buttonColors(backgroundColor = Color.Red, contentColor = Color.White),
                        content = {
                            Text(
                                text = "Remove",
                                fontSize = 1.3.em,
                                modifier = Modifier.padding(7.dp, 0.dp)
                            )
                        },
                        modifier = Modifier.padding(10.dp, 0.dp)
                    )
                }

                // endregion

                // region MythicalTowers

                Row(modifier = Modifier.padding(7.dp, 8.dp)) {
                    Text(
                        text = "MythicalTowers",
                        fontSize = 1.3.em,
                        modifier = Modifier.padding(2.dp, 10.dp)
                    )

                    Button(
                        onClick = {
                            installMod("mythicaltowers", MYTHICALTOWERS_MAIN, modsFolderText.text)
                        },
                        colors = ButtonDefaults.buttonColors(backgroundColor = Color.Green, contentColor = Color.White),
                        content = {
                            Text(
                                text = "Download",
                                fontSize = 1.3.em,
                                modifier = Modifier.padding(7.dp, 0.dp)
                            )
                        },
                        modifier = Modifier.padding(7.dp, 0.dp)
                    )

                    Button(
                        onClick = {
                            updateMod("mythicaltowers", MYTHICALTOWERS_MAIN, modsFolderText.text, cacheFolderText.text)
                        },
                        colors = ButtonDefaults.buttonColors(backgroundColor = Color.Blue, contentColor = Color.White),
                        content = {
                            Text(
                                text = "Update",
                                fontSize = 1.3.em,
                                modifier = Modifier.padding(7.dp, 0.dp)
                            )
                        },
                        modifier = Modifier.padding(10.dp, 0.dp)
                    )

                    Button(
                        onClick = {
                            removeMod("mythicaltowers", modsFolderText.text)
                        },
                        colors = ButtonDefaults.buttonColors(backgroundColor = Color.Red, contentColor = Color.White),
                        content = {
                            Text(
                                text = "Remove",
                                fontSize = 1.3.em,
                                modifier = Modifier.padding(7.dp, 0.dp)
                            )
                        },
                        modifier = Modifier.padding(10.dp, 0.dp)
                    )
                }

                // endregion
            }
        }
    }

    // A little tray when the window is invisible
    if (!isVisible) {
        Tray(
            painterResource("logo.png"),
            hint = "Open MiniManager",
            onAction = {
                isVisible = true
           },
            menu = {
                Item("Exit", onClick = ::exitApplication)
            }
        )
    }
}
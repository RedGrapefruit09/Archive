import okhttp3.*
import java.io.File
import java.io.FileInputStream
import java.io.InputStream
import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.StandardCopyOption
import java.security.MessageDigest
import kotlin.random.Random

// <----  Installation of mods  ---->

/**
 * HTTP [EventListener] logging downloads in debug environments where console's enabled
 */
private class DownloadLogger(private val url: String) : EventListener() {
    override fun cacheMiss(call: Call) {
        super.cacheMiss(call)
        onMiss()
    }

    override fun cacheHit(call: Call, response: Response) {
        super.cacheHit(call, response)
        onHit()
    }

    private fun onMiss(): Unit = println("Downloading asset: $url")
    private fun onHit(): Unit = println("Fetching asset from cache: $url")
}

private const val CACHE_MAX_SIZE: Long = 5000L * 1024L * 1024L // 5GB max for heavy data, Java ZIPs, TAR.GZs etc.

private var assetCache: Cache? = null

/**
 * Initializes the app's OkHttp cache
 */
fun initCache(cacheFolder: String) {
    assetCache = Cache(
        directory = File(cacheFolder),
        maxSize = CACHE_MAX_SIZE
    )
}

/**
 * Downloads a web file at [url] and returns the [InputStream] with the resulting file
 */
fun downloadFileStreamed(url: String): InputStream {
    val client = OkHttpClient.Builder().cache(assetCache!!).eventListener(DownloadLogger(url)).build()
    val request = Request.Builder().url(url).build()

    return client.newCall(request).execute().body!!.byteStream()
}

fun downloadFileSaved(url: String, localPath: String) {
    // Setup local file
    val localFile = File(localPath)
    localFile.createNewFile()
    // Write
    Files.copy(downloadFileStreamed(url), Path.of(localPath), StandardCopyOption.REPLACE_EXISTING)
}

/**
 * Installs a mod named [modName] from [modURL] into [modsFolder]
 */
fun installMod(modName: String, modURL: String, modsFolder: String) {
    // Check if the mod already exists, if yes, remove it.
    val modFile = File(modsFolder, "$modName.jar")
    if (modFile.exists()) modFile.delete()

    // Verify mods folder
    val modsFolderFile = File(modsFolder)
    if (!modsFolderFile.exists()) modsFolderFile.mkdirs()

    // Download the mod
    downloadFileSaved(modURL, modFile.absolutePath)
}

// <----  Removing mods  ---->

/**
 * Removes a mod called [modName] from [modsFolder]
 */
fun removeMod(modName: String, modsFolder: String) {
    val modFile = File(modsFolder, "$modName.jar")
    // Verify mods folder
    val modsFolderFile = File(modsFolder)
    if (!modsFolderFile.exists()) modsFolderFile.mkdirs()

    // Remove mod if it's there
    if (modFile.exists()) modFile.delete()
}

// <----  Updating mods  ---->

/**
 * Updates a mod called [modName] at [modURL] in [modsFolder], if needed.
 */
fun updateMod(modName: String, modURL: String, modsFolder: String, cacheFolderPath: String) {
    // Check if the mod doesn't exist, if yes, download it and quit the operation.
    val modFile = File(modsFolder, "$modName.jar")
    if (modFile.exists()) {
        installMod(modName, modURL, modsFolder)
        return
    }

    // Verify mods folder
    val modsFolderFile = File(modsFolder)
    if (!modsFolderFile.exists()) modsFolderFile.mkdirs()

    // Download the latest JAR from modURL into dedicated cache
    val dedicatedCacheFolder = File("$cacheFolderPath%dedicated%".separate())
    if (!dedicatedCacheFolder.exists()) dedicatedCacheFolder.mkdirs()

    val latestCachedPath = "${dedicatedCacheFolder.absolutePath}%${Random.nextInt(Int.MAX_VALUE)}_upd".separate()
    downloadFileSaved(modURL, latestCachedPath)

    // Compare checksums
    val hasUpdates = sha512Checksum(modFile.absolutePath) == sha512Checksum(latestCachedPath)
    if (!hasUpdates) return

    // Swap out the current JAR with the latest JAR
    Files.copy(Path.of(latestCachedPath), Path.of(modFile.absolutePath), StandardCopyOption.REPLACE_EXISTING)
}

/**
 * Gets an SHA-512 checksum of a file at [path]
 */
private fun sha512Checksum(path: String): String {
    val input = File(path)

    try {
        FileInputStream(input).use { inputStream ->
            val digest = MessageDigest.getInstance("SHA-512")
            val block = ByteArray(4096)
            var length: Int
            while (inputStream.read(block).also { length = it } > 0) {
                digest.update(block, 0, length)
            }
            return digest.digest().also { digest.reset() }.decodeToString()
        }
    } catch (e: Exception) {
        e.printStackTrace()
    }

    throw RuntimeException("Couldn't obtain checksum of file: $path")
}


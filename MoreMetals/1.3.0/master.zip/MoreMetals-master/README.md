This was my 2021 New Year project.  
It isn't developed anymore, but it works just fine and has some cool ingots.  
I **will** maintain it though, so it will always run on the latest versions of Minecraft and Fabric toolchain.